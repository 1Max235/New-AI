package app.atticus

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONObject

/** Everything Atticus can do on the phone. Calls and texts stop at a system screen where YOU confirm. */
class Actions(private val c: Context, private val st: Store) {
    private val am = c.getSystemService(AudioManager::class.java)

    private fun go(i: Intent): String { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "ok" }
    private fun view(url: String, action: String = Intent.ACTION_VIEW) = go(Intent(action, Uri.parse(url)))
    private fun num(s: String) = s.filter { it.isDigit() || it in "+*#" }

    fun run(name: String, a: JSONObject): String = try {
        when (name) {
            "open_app" -> openApp(a.getString("name"))
            "set_timer" -> go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "set_alarm" -> go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "web_search" -> view("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))
            "open_url" -> a.getString("url").let { if (it.startsWith("http")) view(it) else "I only open web links." }
            "navigate" -> view("google.navigation:q=" + Uri.encode(a.getString("destination")))
            "play_music" -> go(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(SearchManager.QUERY, a.getString("query")).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
            "media" -> media(a.getString("action"))
            "flashlight" -> torch(a.getBoolean("on"))
            "set_volume" -> { val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC); am.setStreamVolume(AudioManager.STREAM_MUSIC, max * a.getInt("percent").coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI); "ok" }
            "dial" -> view("tel:" + num(a.getString("number")), Intent.ACTION_DIAL)
            "send_sms" -> go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + num(a.getString("number")))).putExtra("sms_body", a.getString("text")))
            "remember" -> { st.put("memory", (st.s("memory").lines().filter { it.isNotBlank() }.takeLast(49) + a.getString("fact")).joinToString("\n")); "ok" }
            else -> "I don't know how to do $name."
        }
    } catch (e: Exception) { "That didn't work: ${e.message}" }

    /** Built-in commands that never touch the network. Returns true if handled. */
    fun instant(text: String): Boolean {
        val t = text.lowercase().trim().trimEnd('.', '!', '?')
        Regex("^(?:open|launch|start) (.+)$").find(t)?.let { return run("open_app", JSONObject().put("name", it.groupValues[1])) == "ok" }
        Regex("^(?:turn )?(?:the )?(?:flashlight|torch) (on|off)$|^(?:turn )?(on|off) (?:the )?(?:flashlight|torch)$").find(t)?.let {
            return run("flashlight", JSONObject().put("on", (it.groupValues[1] + it.groupValues[2]) == "on")) == "ok"
        }
        Regex("^(?:turn )?(?:the )?volume (up|down)$|^(?:turn )?(up|down) (?:the )?volume$").find(t)?.let {
            val up = (it.groupValues[1] + it.groupValues[2]) == "up"
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return true
        }
        return when (t) {
            "pause", "play", "resume", "pause music", "stop music", "play music" -> media("playpause") == "ok"
            "next", "skip", "next song", "next track", "skip song" -> media("next") == "ok"
            "previous", "previous song", "previous track" -> media("previous") == "ok"
            else -> false
        }
    }

    private fun openApp(name: String): String {
        val pm = c.packageManager; val q = name.lowercase().trim()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.ResolveInfoFlags.of(0L))
        val hit = apps.filter { val l = it.loadLabel(pm).toString().lowercase(); l.isNotEmpty() && (l.contains(q) || q.contains(l)) }
            .minByOrNull { it.loadLabel(pm).length } ?: return "I couldn't find an app called $name."
        return go(pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "I can't open $name.")
    }

    private fun torch(on: Boolean): String {
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return "I couldn't find a flashlight."
        cm.setTorchMode(id, on); return "ok"
    }

    private fun media(a: String): String {
        val code = when (a) { "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "ok"
    }
}
