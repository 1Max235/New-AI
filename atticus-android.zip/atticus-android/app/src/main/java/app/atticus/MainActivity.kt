package app.atticus

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.WindowInsets
import android.widget.*

class MainActivity : Activity() {
    private val st by lazy { Store(this) }
    private lateinit var status: TextView

    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun tick(b: Boolean) = if (b) "✓" else "✗"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun btn(label: String, f: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { f() } }
        val key = EditText(this).apply {
            hint = if (st.s("key").isBlank()) "Anthropic API key (sk-ant-…)" else "Key saved ✓ (paste to replace)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val model = EditText(this).apply { setText(st.s("model", "claude-haiku-5-5")); inputType = InputType.TYPE_CLASS_TEXT }
        status = TextView(this).apply { setPadding(0, (12 * d).toInt(), 0, 0) }
        val svc = Intent(this, AssistantService::class.java)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "Atticus"; textSize = 28f })
            addView(key); addView(model)
            addView(btn("1 · Allow microphone + notifications") {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
            })
            addView(btn("2 · Allow floating bubble") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            addView(btn("3 · Save & start") {
                if (key.text.isNotBlank()) st.put("key", key.text.toString().trim())
                st.put("model", model.text.toString().trim().ifEmpty { "claude-haiku-5-5" })
                if (micOk() && Settings.canDrawOverlays(this@MainActivity)) startForegroundService(svc)
                else Toast.makeText(this@MainActivity, "Finish steps 1 and 2 first", Toast.LENGTH_LONG).show()
                refresh()
            })
            addView(btn("Stop") { stopService(svc) })
            addView(btn("Forget memory + shortcuts") { st.put("memory", ""); st.put("shortcuts", "{}") })
            addView(status)
        }
        setContentView(ScrollView(this).apply {
            setOnApplyWindowInsetsListener { v, i ->
                val s = i.getInsets(WindowInsets.Type.systemBars()); val p = (16 * d).toInt()
                v.setPadding(p + s.left, p + s.top, p + s.right, p + s.bottom); i
            }
            addView(col)
        })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = "Mic ${tick(micOk())}   Bubble ${tick(Settings.canDrawOverlays(this))}   Key ${tick(st.s("key").isNotBlank())}\n\n" +
            "Hold the bubble, talk, let go. To move it, press and drag a long way."
    }
}
