package app.atticus

import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tiny private key-value store: API key, model, memory, learned shortcuts, bubble position. */
class Store(c: Context) {
    private val p = c.getSharedPreferences("atticus", Context.MODE_PRIVATE)
    fun s(k: String, d: String = "") = p.getString(k, d) ?: d
    fun put(k: String, v: String) = p.edit().putString(k, v).apply()
    fun i(k: String, d: Int) = p.getInt(k, d)
    fun putI(k: String, v: Int) = p.edit().putInt(k, v).apply()
    fun shortcuts() = JSONObject(s("shortcuts", "{}"))
    fun learn(k: String, calls: JSONArray) { val o = shortcuts(); if (o.length() < 200) put("shortcuts", o.put(k, calls).toString()) }
}

/** Text in -> (instant command | learned shortcut | Claude with tools) -> text to speak. */
class Brain(private val c: Context, private val st: Store, private val act: Actions) {

    private fun t(name: String, desc: String, vararg p: Pair<String, String>) = JSONObject()
        .put("name", name).put("description", desc)
        .put("input_schema", JSONObject().put("type", "object")
            .put("properties", JSONObject().also { o -> p.forEach { (k, ty) -> o.put(k, JSONObject().put("type", ty)) } })
            .put("required", JSONArray(p.map { it.first })))

    private val tools = JSONArray(listOf(
        t("open_app", "Open an installed app by name", "name" to "string"),
        t("set_timer", "Start a countdown timer", "seconds" to "integer"),
        t("set_alarm", "Set an alarm (24h clock)", "hour" to "integer", "minute" to "integer"),
        t("web_search", "Search the web in the browser", "query" to "string"),
        t("open_url", "Open an http(s) link", "url" to "string"),
        t("navigate", "Start navigation to a place", "destination" to "string"),
        t("play_music", "Play a song, artist or playlist", "query" to "string"),
        t("media", "Media key: playpause, next or previous", "action" to "string"),
        t("flashlight", "Turn the flashlight on or off", "on" to "boolean"),
        t("set_volume", "Set media volume 0-100", "percent" to "integer"),
        t("dial", "Open the dialer with a number (user presses call)", "number" to "string"),
        t("send_sms", "Open a text draft (user presses send)", "number" to "string", "text" to "string"),
        t("remember", "Save a lasting fact about the user (names, numbers, preferences)", "fact" to "string"),
    ))

    private fun system(): String {
        val bat = c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val now = SimpleDateFormat("EEEE d MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        return "You are Atticus, a voice assistant on the user's Android phone. Your reply is read aloud: at most 2 short sentences, no markdown. " +
            "Use tools to act on the phone (several at once is fine) and don't narrate them. If you lack a number or app name, ask briefly instead of guessing. " +
            "Now: $now. Battery: $bat%.\nWhat you know about the user:\n" + st.s("memory", "").ifBlank { "(nothing yet)" }
    }

    private fun norm(x: String) = x.lowercase().replace(Regex("[^a-z0-9 ]"), "").trim()

    private fun exec(calls: JSONArray) = (0 until calls.length()).map { calls.getJSONObject(it) }
        .map { act.run(it.getString("name"), it.getJSONObject("input")) }.filter { it != "ok" }

    private fun done(said: String, fails: List<String>) = (said + " " + fails.joinToString(" ")).trim().ifEmpty { "Done." }

    fun ask(text: String): String {
        if (act.instant(text)) return "Done."
        val k = norm(text)
        st.shortcuts().optJSONArray(k)?.let { return done("", exec(it)) }   // learned: no API call
        val key = st.s("key")
        if (key.isBlank()) return "Open the Atticus app and add your Anthropic API key."

        val body = JSONObject().put("model", st.s("model", "claude-haiku-5-5")).put("max_tokens", 400)
            .put("system", system()).put("tools", tools)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
        val con = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 10_000; readTimeout = 30_000
            setRequestProperty("x-api-key", key)
            setRequestProperty("anthropic-version", "2023-06-01")
            setRequestProperty("content-type", "application/json")
        }
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val resp = (if (code in 200..299) con.inputStream else con.errorStream).bufferedReader().readText()
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(resp).getJSONObject("error").getString("message") }.getOrDefault("")
            return "Claude error $code. $msg"
        }

        val content = JSONObject(resp).getJSONArray("content")
        val said = StringBuilder(); val calls = JSONArray()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            when (b.getString("type")) {
                "text" -> said.append(b.getString("text")).append(' ')
                "tool_use" -> calls.put(JSONObject().put("name", b.getString("name")).put("input", b.getJSONObject("input")))
            }
        }
        val fails = exec(calls)
        val plain = (0 until calls.length()).none { calls.getJSONObject(it).getString("name") == "remember" }
        if (k.isNotEmpty() && calls.length() > 0 && fails.isEmpty() && plain) st.learn(k, calls)  // learn this phrase
        return done(said.toString(), fails)
    }
}
