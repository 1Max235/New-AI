package app.atticus

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.hypot

/** Floating hold-to-talk bubble: hold, speak, release. On-device speech -> Brain -> spoken reply. */
class AssistantService : Service(), RecognitionListener {
    private enum class Mode(val color: Int) {
        IDLE(0xFF3B5BDB.toInt()), LISTEN(0xFFE03131.toInt()), THINK(0xFFF08C00.toInt()), SPEAK(0xFF2F9E44.toInt())
    }

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var caption: TextView
    private lateinit var bubble: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var store: Store
    private lateinit var brain: Brain
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private var onDevice = true
    private var mode = Mode.IDLE
    private var holding = false
    private var gen = 0
    private val heard = StringBuilder()
    private val giveUp = Runnable { if (mode == Mode.LISTEN) finishListening() }
    private val hide = Runnable { caption.visibility = View.GONE }
    private val speech by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("atticus", "Atticus", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "atticus").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Atticus is ready").setContentText("Hold the bubble and talk").setContentIntent(open).build(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        store = Store(this); brain = Brain(this, store, Actions(this, store))
        tts = TextToSpeech(this) {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { ui.post { setMode(Mode.IDLE) } }
                @Deprecated("required override") override fun onError(id: String?) { ui.post { setMode(Mode.IDLE) } }
            })
        }
        wm = getSystemService(WindowManager::class.java)
        buildOverlay(); newRecognizer()
    }

    override fun onDestroy() {
        rec?.destroy(); if (::tts.isInitialized) tts.shutdown()
        if (::root.isInitialized) wm.removeView(root)
        io.shutdownNow(); super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        caption = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; maxWidth = dp(240); visibility = View.GONE
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xE6212529.toInt()) }
        }
        bubble = TextView(this).apply {
            text = "🎙"; textSize = 26f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Mode.IDLE.color) }
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.END
            addView(caption)
            addView(bubble, LinearLayout.LayoutParams(dp(64), dp(64)).apply { topMargin = dp(6) })
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = store.i("x", dp(8)); y = store.i("y", resources.displayMetrics.heightPixels / 2) }

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var drag = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; drag = false; press() }
                    MotionEvent.ACTION_MOVE -> {
                        if (!drag && hypot(e.rawX - sx, e.rawY - sy) > dp(24)) { drag = true; cancel() }  // big move = drag the bubble
                        if (drag) { lp.x = ox - (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp) }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        if (drag) { store.putI("x", lp.x); store.putI("y", lp.y) } else release()
                }
                return true
            }
        })
        wm.addView(root, lp)
    }

    private fun setMode(m: Mode) { mode = m; (bubble.background as GradientDrawable).setColor(m.color) }

    private fun show(t: String) {
        caption.text = t; caption.visibility = View.VISIBLE
        ui.removeCallbacks(hide); if (mode != Mode.LISTEN) ui.postDelayed(hide, 6000)
    }

    private fun newRecognizer() {
        rec?.destroy()
        rec = (if (onDevice && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
               else SpeechRecognizer.createSpeechRecognizer(this)).apply { setRecognitionListener(this@AssistantService) }
    }

    // ---- hold to talk ----
    private fun press() {
        gen++; tts.stop(); holding = true; heard.setLength(0); ui.removeCallbacks(giveUp)
        setMode(Mode.LISTEN); show("Listening…"); rec?.startListening(speech)
    }
    private fun release() {
        holding = false
        if (mode == Mode.LISTEN) { rec?.stopListening(); ui.postDelayed(giveUp, 3000) }
    }
    private fun cancel() { holding = false; ui.removeCallbacks(giveUp); rec?.cancel(); heard.setLength(0); setMode(Mode.IDLE); caption.visibility = View.GONE }

    private fun finishListening() {
        ui.removeCallbacks(giveUp)
        val text = heard.toString().trim(); heard.setLength(0)
        if (text.isEmpty()) { setMode(Mode.IDLE); caption.visibility = View.GONE; return }
        setMode(Mode.THINK); show(text)
        val g = gen
        io.execute {
            val reply = try { brain.ask(text) } catch (e: Exception) { "Something went wrong: ${e.message}" }
            ui.post { if (g == gen) { show(reply); setMode(Mode.SPEAK); tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "r") } }
        }
    }

    // ---- speech callbacks ----
    override fun onResults(r: Bundle?) {
        r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard.append(it).append(' ') }
        if (holding) rec?.startListening(speech) else finishListening()   // recognizer ended early but finger is still down
    }
    override fun onPartialResults(p: Bundle?) {
        p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { show("$heard$it".trim()) }
    }
    override fun onError(e: Int) {
        when {
            e == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE || e == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> {
                onDevice = false; newRecognizer(); if (holding) rec?.startListening(speech) else finishListening()  // no offline pack: use system recognizer
            }
            holding && (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) -> rec?.startListening(speech)
            !holding -> finishListening()
        }
    }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, p: Bundle?) {}
}
