plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.atticus"
    compileSdk = 36
    defaultConfig { applicationId = "app.atticus"; minSdk = 34; targetSdk = 36; versionCode = 1; versionName = "0.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
